from django.shortcuts import render
from django.views.generic import ListView,DeleteView,CreateView,DetailView,UpdateView
from testapp.models import company
from django.core.urlresolvers import reverse_lazy

class companylistview(ListView):
    model=company
class companydetailview(DetailView):
    model=company
class companycreateview(CreateView):
    model=company
    fields=('name','location','ceo')
class companyupdateview(UpdateView):
    model=company
    fields=('name','ceo')
class companydeleteview(DeleteView):
    model=company
    success_url=reverse_lazy('companies')
